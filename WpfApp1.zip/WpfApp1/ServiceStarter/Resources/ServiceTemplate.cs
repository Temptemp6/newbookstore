﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceStarter.Resources
{

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Runtime.Serialization", "4.0.0.0")]
    [System.Runtime.Serialization.DataContractAttribute(Name = "test", Namespace = "http://schemas.datacontract.org/2004/07/WcfService1")]
    [System.SerializableAttribute()]
    public partial class test : object, System.Runtime.Serialization.IExtensibleDataObject, System.ComponentModel.INotifyPropertyChanged
    {

        [System.NonSerializedAttribute()]
        private System.Runtime.Serialization.ExtensionDataObject extensionDataField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private string BnameField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private string GbookField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private long IDField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private string PbookField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private bool RemovecheckField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private string StockbookField;

        [global::System.ComponentModel.BrowsableAttribute(false)]
        public System.Runtime.Serialization.ExtensionDataObject ExtensionData
        {
            get
            {
                return this.extensionDataField;
            }
            set
            {
                this.extensionDataField = value;
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Bname
        {
            get
            {
                return this.BnameField;
            }
            set
            {
                if ((object.ReferenceEquals(this.BnameField, value) != true))
                {
                    this.BnameField = value;
                    this.RaisePropertyChanged("Bname");
                }
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Gbook
        {
            get
            {
                return this.GbookField;
            }
            set
            {
                if ((object.ReferenceEquals(this.GbookField, value) != true))
                {
                    this.GbookField = value;
                    this.RaisePropertyChanged("Gbook");
                }
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public long ID
        {
            get
            {
                return this.IDField;
            }
            set
            {
                if ((this.IDField.Equals(value) != true))
                {
                    this.IDField = value;
                    this.RaisePropertyChanged("ID");
                }
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Pbook
        {
            get
            {
                return this.PbookField;
            }
            set
            {
                if ((object.ReferenceEquals(this.PbookField, value) != true))
                {
                    this.PbookField = value;
                    this.RaisePropertyChanged("Pbook");
                }
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public bool Removecheck
        {
            get
            {
                return this.RemovecheckField;
            }
            set
            {
                if ((this.RemovecheckField.Equals(value) != true))
                {
                    this.RemovecheckField = value;
                    this.RaisePropertyChanged("Removecheck");
                }
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Stockbook
        {
            get
            {
                return this.StockbookField;
            }
            set
            {
                if ((object.ReferenceEquals(this.StockbookField, value) != true))
                {
                    this.StockbookField = value;
                    this.RaisePropertyChanged("Stockbook");
                }
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }


    ///
    //####################################
    //
    //
    //
    public partial class CompositeType : object, System.Runtime.Serialization.IExtensibleDataObject, System.ComponentModel.INotifyPropertyChanged
    {

        [System.NonSerializedAttribute()]
        private System.Runtime.Serialization.ExtensionDataObject extensionDataField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private bool BoolValueField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private string StringValueField;

        [global::System.ComponentModel.BrowsableAttribute(false)]
        public System.Runtime.Serialization.ExtensionDataObject ExtensionData
        {
            get
            {
                return this.extensionDataField;
            }
            set
            {
                this.extensionDataField = value;
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public bool BoolValue
        {
            get
            {
                return this.BoolValueField;
            }
            set
            {
                if ((this.BoolValueField.Equals(value) != true))
                {
                    this.BoolValueField = value;
                    this.RaisePropertyChanged("BoolValue");
                }
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string StringValue
        {
            get
            {
                return this.StringValueField;
            }
            set
            {
                if ((object.ReferenceEquals(this.StringValueField, value) != true))
                {
                    this.StringValueField = value;
                    this.RaisePropertyChanged("StringValue");
                }
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }


    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.ServiceContractAttribute(ConfigurationName = "IService")]
    public interface IService
    {

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/InitData", ReplyAction = "http://tempuri.org/IService1/InitDataResponse")]
        void InitData();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/InitData", ReplyAction = "http://tempuri.org/IService1/InitDataResponse")]
        System.Threading.Tasks.Task InitDataAsync();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/GetData", ReplyAction = "http://tempuri.org/IService1/GetDataResponse")]
        string GetData();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/GetData", ReplyAction = "http://tempuri.org/IService1/GetDataResponse")]
        System.Threading.Tasks.Task<string> GetDataAsync();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/AddBook", ReplyAction = "http://tempuri.org/IService1/AddBookResponse")]
        long AddBook(int val1, string str1, string str2, string str3, string str4, bool bool1);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/AddBook", ReplyAction = "http://tempuri.org/IService1/AddBookResponse")]
        System.Threading.Tasks.Task<long> AddBookAsync(int val1, string str1, string str2, string str3, string str4, bool bool1);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/DeleteBook", ReplyAction = "http://tempuri.org/IService1/DeleteBookResponse")]
        bool DeleteBook(long IDval);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/DeleteBook", ReplyAction = "http://tempuri.org/IService1/DeleteBookResponse")]
        System.Threading.Tasks.Task<bool> DeleteBookAsync(long IDval);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/EditBook", ReplyAction = "http://tempuri.org/IService1/EditBookResponse")]
        bool EditBook([System.ServiceModel.MessageParameterAttribute(Name = "editbook")] ServiceStarter.Resources.test editbook1);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/EditBook", ReplyAction = "http://tempuri.org/IService1/EditBookResponse")]
        System.Threading.Tasks.Task<bool> EditBookAsync(ServiceStarter.Resources.test editbook);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/ConnectDist", ReplyAction = "http://tempuri.org/IService1/ConnectDistResponse")]
        bool ConnectDist();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/ConnectDist", ReplyAction = "http://tempuri.org/IService1/ConnectDistResponse")]
        System.Threading.Tasks.Task<bool> ConnectDistAsync();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/GetDataUsingDataContract", ReplyAction = "http://tempuri.org/IService1/GetDataUsingDataContractResponse")]
        ServiceStarter.Resources.CompositeType GetDataUsingDataContract(ServiceStarter.Resources.CompositeType composite);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/GetDataUsingDataContract", ReplyAction = "http://tempuri.org/IService1/GetDataUsingDataContractResponse")]
        System.Threading.Tasks.Task<ServiceStarter.Resources.CompositeType> GetDataUsingDataContractAsync(ServiceStarter.Resources.CompositeType composite);
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    public interface IService1Channel : ServiceStarter.Resources.IService, System.ServiceModel.IClientChannel
    {
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    public partial class Service1Client : System.ServiceModel.ClientBase<ServiceStarter.Resources.IService>, ServiceStarter.Resources.IService
    {

        public Service1Client()
        {
        }

        public Service1Client(string endpointConfigurationName) :
                base(endpointConfigurationName)
        {
        }

        public Service1Client(string endpointConfigurationName, string remoteAddress) :
                base(endpointConfigurationName, remoteAddress)
        {
        }

        public Service1Client(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress) :
                base(endpointConfigurationName, remoteAddress)
        {
        }

        public Service1Client(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) :
                base(binding, remoteAddress)
        {
        }

        public void InitData()
        {
            base.Channel.InitData();
        }

        public System.Threading.Tasks.Task InitDataAsync()
        {
            return base.Channel.InitDataAsync();
        }

        public string GetData()
        {
            return base.Channel.GetData();
        }

        public System.Threading.Tasks.Task<string> GetDataAsync()
        {
            return base.Channel.GetDataAsync();
        }

        public long AddBook(int val1, string str1, string str2, string str3, string str4, bool bool1)
        {
            return base.Channel.AddBook(val1, str1, str2, str3, str4, bool1);
        }

        public System.Threading.Tasks.Task<long> AddBookAsync(int val1, string str1, string str2, string str3, string str4, bool bool1)
        {
            return base.Channel.AddBookAsync(val1, str1, str2, str3, str4, bool1);
        }

        public bool DeleteBook(long IDval)
        {
            return base.Channel.DeleteBook(IDval);
        }

        public System.Threading.Tasks.Task<bool> DeleteBookAsync(long IDval)
        {
            return base.Channel.DeleteBookAsync(IDval);
        }

        public bool EditBook(ServiceStarter.Resources.test editbook1)
        {
            return base.Channel.EditBook(editbook1);
        }

        public System.Threading.Tasks.Task<bool> EditBookAsync(ServiceStarter.Resources.test editbook)
        {
            return base.Channel.EditBookAsync(editbook);
        }

        public bool ConnectDist()
        {
            return base.Channel.ConnectDist();
        }

        public System.Threading.Tasks.Task<bool> ConnectDistAsync()
        {
            return base.Channel.ConnectDistAsync();
        }

        public ServiceStarter.Resources.CompositeType GetDataUsingDataContract(ServiceStarter.Resources.CompositeType composite)
        {
            return base.Channel.GetDataUsingDataContract(composite);
        }

        public System.Threading.Tasks.Task<ServiceStarter.Resources.CompositeType> GetDataUsingDataContractAsync(ServiceStarter.Resources.CompositeType composite)
        {
            return base.Channel.GetDataUsingDataContractAsync(composite);
        }
    }
}
