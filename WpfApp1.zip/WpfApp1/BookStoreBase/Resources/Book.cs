﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStoreBase.Resources
{
    [Serializable]
    public class Book
    {
        public Int64 _id;
        public Int64 ID { get { return _id; } set { _id = value; } }

        public string _bname;
        public string Bname { get { return _bname; } set { _bname = value; } }

        public string _gbook;
        public string Gbook { get { return _gbook; } set { _gbook = value; } }

        public string _pbook;
        public string Pbook { get { return _pbook; } set { _pbook = value; } }

        public string _stockbook;
        public string Stockbook { get { return _stockbook; } set { _stockbook = value; } }

        public bool _removecheck;
        public bool Removecheck { get { return _removecheck; } set { _removecheck = value; } }

        public Book() { }

        public Book(Int64 tID, string name, string genre, string price, string stock, bool remcheck = false)
        {
            ID = tID;
            Bname = name;
            Gbook = genre;
            Pbook = price;
            Stockbook = stock;
            Removecheck = remcheck;
        }
    }
}
