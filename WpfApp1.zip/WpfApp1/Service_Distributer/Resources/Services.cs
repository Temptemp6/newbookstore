﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ServiceModel;

using Service_Distributer.Resources;

namespace Service_Distributer.Resources
{
    public class Services
    {
        private List<string> ports;

        private int lastportid = -1;

        private Services()
        {
            ports = new List<string>();
        }

        private static Services instance;
        public static Services Instance
        {
            get
            {
                if (instance == null) { instance = new Services(); }
                return instance;
            }
        }

        public string getOpenPort()
        {
            if(lastportid > ports.Count - 2)
            {
                lastportid = -1;
            }

            if (ports.Count < 1)
                return null;

            lastportid += 1;
            return ports[lastportid];
        }

        public void addPort(string newport)
        {
            if (ports.Count == 0)
            {
                ports.Add(newport);
                return;
            }
            else if(ports.Where(r => r == newport).Select(r => r).ToList().Count == 0)
            {
                ports.Add(newport);
                return;
            }
        }

        public void removePort(string newport)
        {
            ports.RemoveAll(r => r == newport);
        }

        public int getNumPorts()
        {
            return ports.Count;
        }

        public void checkports()
        {
            foreach (var portnum in ports)
            {
                try
                {
                    BasicHttpBinding myBinding = new BasicHttpBinding();

                    EndpointAddress myEndpoint = new EndpointAddress("http://localhost:" + portnum + "/Service1.svc"); //63484 //53956

                    ChannelFactory<IService> myChannelFactory = new ChannelFactory<IService>(myBinding, myEndpoint);

                    // Create a channel.
                    IService wcfClient1 = myChannelFactory.CreateChannel();
                    bool s = wcfClient1.ConnectDist();
                    //Console.WriteLine(s.ToString());
                    ((IClientChannel)wcfClient1).Close();
                    //other service
                }
                catch
                {
                    removePort(portnum);
                }
            }
        }
    }
}