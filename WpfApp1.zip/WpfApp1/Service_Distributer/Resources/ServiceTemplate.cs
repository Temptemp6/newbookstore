﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service_Distributer.Resources
{
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.ServiceContractAttribute(ConfigurationName = "IService")]
    public interface IService
    {

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/InitData", ReplyAction = "http://tempuri.org/IService1/InitDataResponse")]
        void InitData();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/InitData", ReplyAction = "http://tempuri.org/IService1/InitDataResponse")]
        System.Threading.Tasks.Task InitDataAsync();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/GetData", ReplyAction = "http://tempuri.org/IService1/GetDataResponse")]
        Service_Distributer.Resources.test[] GetData();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/GetData", ReplyAction = "http://tempuri.org/IService1/GetDataResponse")]
        System.Threading.Tasks.Task<Service_Distributer.Resources.test[]> GetDataAsync();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/AddBook", ReplyAction = "http://tempuri.org/IService1/AddBookResponse")]
        long AddBook(int val1, string str1, string str2, string str3, string str4, bool bool1);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/AddBook", ReplyAction = "http://tempuri.org/IService1/AddBookResponse")]
        System.Threading.Tasks.Task<long> AddBookAsync(int val1, string str1, string str2, string str3, string str4, bool bool1);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/DeleteBook", ReplyAction = "http://tempuri.org/IService1/DeleteBookResponse")]
        bool DeleteBook(long IDval);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/DeleteBook", ReplyAction = "http://tempuri.org/IService1/DeleteBookResponse")]
        System.Threading.Tasks.Task<bool> DeleteBookAsync(long IDval);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/EditBook", ReplyAction = "http://tempuri.org/IService1/EditBookResponse")]
        bool EditBook([System.ServiceModel.MessageParameterAttribute(Name = "editbook")] Service_Distributer.Resources.test editbook1);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/EditBook", ReplyAction = "http://tempuri.org/IService1/EditBookResponse")]
        System.Threading.Tasks.Task<bool> EditBookAsync(Service_Distributer.Resources.test editbook);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/ConnectDist", ReplyAction = "http://tempuri.org/IService1/ConnectDistResponse")]
        bool ConnectDist();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/ConnectDist", ReplyAction = "http://tempuri.org/IService1/ConnectDistResponse")]
        System.Threading.Tasks.Task<bool> ConnectDistAsync();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/GetDataUsingDataContract", ReplyAction = "http://tempuri.org/IService1/GetDataUsingDataContractResponse")]
        Service_Distributer.Resources.CompositeType GetDataUsingDataContract(Service_Distributer.Resources.CompositeType composite);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/GetDataUsingDataContract", ReplyAction = "http://tempuri.org/IService1/GetDataUsingDataContractResponse")]
        System.Threading.Tasks.Task<Service_Distributer.Resources.CompositeType> GetDataUsingDataContractAsync(Service_Distributer.Resources.CompositeType composite);
    }


    public partial class test : object, System.Runtime.Serialization.IExtensibleDataObject, System.ComponentModel.INotifyPropertyChanged
    {

        [System.NonSerializedAttribute()]
        private System.Runtime.Serialization.ExtensionDataObject extensionDataField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private string BnameField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private string GbookField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private long IDField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private string PbookField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private bool RemovecheckField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private string StockbookField;

        [global::System.ComponentModel.BrowsableAttribute(false)]
        public System.Runtime.Serialization.ExtensionDataObject ExtensionData
        {
            get
            {
                return this.extensionDataField;
            }
            set
            {
                this.extensionDataField = value;
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Bname
        {
            get
            {
                return this.BnameField;
            }
            set
            {
                if ((object.ReferenceEquals(this.BnameField, value) != true))
                {
                    this.BnameField = value;
                    this.RaisePropertyChanged("Bname");
                }
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Gbook
        {
            get
            {
                return this.GbookField;
            }
            set
            {
                if ((object.ReferenceEquals(this.GbookField, value) != true))
                {
                    this.GbookField = value;
                    this.RaisePropertyChanged("Gbook");
                }
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public long ID
        {
            get
            {
                return this.IDField;
            }
            set
            {
                if ((this.IDField.Equals(value) != true))
                {
                    this.IDField = value;
                    this.RaisePropertyChanged("ID");
                }
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Pbook
        {
            get
            {
                return this.PbookField;
            }
            set
            {
                if ((object.ReferenceEquals(this.PbookField, value) != true))
                {
                    this.PbookField = value;
                    this.RaisePropertyChanged("Pbook");
                }
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public bool Removecheck
        {
            get
            {
                return this.RemovecheckField;
            }
            set
            {
                if ((this.RemovecheckField.Equals(value) != true))
                {
                    this.RemovecheckField = value;
                    this.RaisePropertyChanged("Removecheck");
                }
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string Stockbook
        {
            get
            {
                return this.StockbookField;
            }
            set
            {
                if ((object.ReferenceEquals(this.StockbookField, value) != true))
                {
                    this.StockbookField = value;
                    this.RaisePropertyChanged("Stockbook");
                }
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }


    ///
    //####################################
    //
    //
    //
    public partial class CompositeType : object, System.Runtime.Serialization.IExtensibleDataObject, System.ComponentModel.INotifyPropertyChanged
    {

        [System.NonSerializedAttribute()]
        private System.Runtime.Serialization.ExtensionDataObject extensionDataField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private bool BoolValueField;

        [System.Runtime.Serialization.OptionalFieldAttribute()]
        private string StringValueField;

        [global::System.ComponentModel.BrowsableAttribute(false)]
        public System.Runtime.Serialization.ExtensionDataObject ExtensionData
        {
            get
            {
                return this.extensionDataField;
            }
            set
            {
                this.extensionDataField = value;
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public bool BoolValue
        {
            get
            {
                return this.BoolValueField;
            }
            set
            {
                if ((this.BoolValueField.Equals(value) != true))
                {
                    this.BoolValueField = value;
                    this.RaisePropertyChanged("BoolValue");
                }
            }
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string StringValue
        {
            get
            {
                return this.StringValueField;
            }
            set
            {
                if ((object.ReferenceEquals(this.StringValueField, value) != true))
                {
                    this.StringValueField = value;
                    this.RaisePropertyChanged("StringValue");
                }
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
