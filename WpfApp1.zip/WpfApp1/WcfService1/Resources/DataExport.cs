﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using System.Threading;

using BookStoreBase.Resources;

namespace WcfService1.Resources
{
    public class DataLock
    {
        private int lockvar = 0;
        private DataLock()
        {
            lockvar = 0;
        }

        private static DataLock instance;
        public static DataLock Instance
        {
            get
            {
                if (instance == null) { instance = new DataLock(); }
                return instance;
            }
        }

        public int getlock()
        {
            return lockvar;
        }

        public void trygetlock(int trylock)
        {
            if(lockvar == 0)
            {
                lockvar = trylock;
            }
        }

        public void releaselock()
        {
            lockvar = 0;
        }
    }


    public class DataExport
    {
        private string pathvar = "";

        public List<Book> readcsv()
        {
            //pathvar = System.Environment.CurrentDirectory;

            List<Book> books = new List<Book>();
            pathvar = "C:\\Projects\\WpfApp1\\WcfService1\\bin";

            if (File.Exists(pathvar + "\\Library.csv"))
            {
                using (var reader = new StreamReader(pathvar + "\\Library.csv"))
                {
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var values = line.Split(',');
                        Book tempb = new Book(Int32.Parse(values[0]), values[1], values[2], values[3], values[4]);
                        books.Add(tempb);
                    }
                }
            }

            return books;
        }

        public void savedata(ConcurrentQueue<List<Book>> cq, ConcurrentQueue<string> lq)
        {

            List<Book> t;
            List<Book> last = null;
            while (true)
            {
                DataLock datalock = DataLock.Instance;
                try
                {
                    while (datalock.getlock() != 2)
                    {
                        datalock.trygetlock(2);
                        Thread.Sleep(100);
                    }


                    while (cq.TryDequeue(out t))
                    {
                        last = t;
                    }
                    if (last != null)
                    {
                        writetofile(last);
                    }

                    if (lq.IsEmpty == false)
                    {
                        logfile(lq);
                    }

                    if (datalock.getlock() == 2)
                    {
                        datalock.releaselock();
                    }
                    last = null;

                    Thread.Sleep(2000);
                }
                catch
                {

                }
            }

            return;
        }

        public int logfile(ConcurrentQueue<string> lq)
        {
            string outval;
            pathvar = "C:\\Projects\\WpfApp1\\WcfService1\\bin";
            try
            {
                List<string> templog = new List<string>();
                while (lq.TryDequeue(out outval))
                {
                    if(outval != null && outval != "")
                        templog.Add(outval);
                }

                using (StreamWriter w = File.AppendText(pathvar + "\\LogFile.txt"))
                {
                    foreach (var item in templog)
                    {
                        w.WriteLine(item);
                    }
                }
            }
            catch
            {
                return -1;
            }
            return 1;
        }

        public int writetofile(List<Book> library)
        {

            pathvar = "C:\\Projects\\WpfApp1\\WcfService1\\bin";
            try
            {
                using (StreamWriter file = new StreamWriter(pathvar + "\\Library.tmp"))
                {
                    foreach (var item in library)
                    {
                        file.WriteLine(item.ID + "," + item.Bname + "," + item.Gbook + "," + item.Pbook + "," + item.Stockbook);
                    }
                }
            }
            catch (Exception ex)
            {
                return -1;
            }

            int changefilename = -1;
            int cnt = 0;

            //delete old temp file
            try
            {
                File.Delete(pathvar + "\\Library_old.tmp");
            }
            catch (Exception ex)
            {
            }


            while (changefilename == -1 && cnt < 15)
            {
                try
                {
                    if (File.Exists(pathvar + "\\Library.csv"))
                    {
                        File.Move(pathvar + "\\Library.csv", pathvar + "\\Library_old.tmp");
                    }


                    if (!(File.Exists(pathvar + "\\Library.csv")))
                    {
                        if (File.Exists(pathvar + "\\Library.tmp"))
                        {
                            File.Move(pathvar + "\\Library.tmp", pathvar + "\\Library.csv");
                            File.Delete(pathvar + "\\Library_old.tmp");
                            return 1;
                        }
                    }
                    //change file name
                }
                catch (Exception ex)
                {
                    cnt++;
                }
            }

            return 1;
        }
    }
}
