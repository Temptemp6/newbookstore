﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using BookStoreBase.Resources;

using System.Threading.Tasks;

namespace WcfService2
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        void InitData();

        [OperationContract]
        List<Book> GetData();

        [OperationContract]
        Int64 AddBook(int val1, string str1, string str2, string str3, string str4, bool bool1);

        [OperationContract]
        bool DeleteBook(Int64 IDval);

        [OperationContract]
        bool EditBook(Book editbook);

        [OperationContract]
        bool ConnectDist();

        // TODO: Add your service operations here
    }

    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class test
    {
        [DataMember]
        public Int64 ID { get; set; }

        [DataMember]
        public string Bname { get; set; }

        [DataMember]
        public string Gbook { get; set; }

        [DataMember]
        public string Pbook { get; set; }

        [DataMember]
        public string Stockbook { get; set; }

        [DataMember]
        public bool Removecheck { get; set; }

        public test(Int64 tID, string name, string genre, string price, string stock, bool remcheck = false)
        {
            ID = tID;
            Bname = name;
            Gbook = genre;
            Pbook = price;
            Stockbook = stock;
            Removecheck = remcheck;
        }
    }
}
