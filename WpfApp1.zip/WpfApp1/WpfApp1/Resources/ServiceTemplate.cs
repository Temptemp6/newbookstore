﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ServiceModel;
using WpfApp1.ServiceDist;

namespace WpfApp1.Resources
{

    ///
    //This is all the functions for the service contract
    //
    //
    //


    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.ServiceContractAttribute(ConfigurationName = "IService")]
    public interface IService
    {

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/InitData", ReplyAction = "http://tempuri.org/IService1/InitDataResponse")]
        void InitData();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/InitData", ReplyAction = "http://tempuri.org/IService1/InitDataResponse")]
        System.Threading.Tasks.Task InitDataAsync();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/GetData", ReplyAction = "http://tempuri.org/IService1/GetDataResponse")]
        BookStoreBase.Resources.Book[] GetData();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/GetData", ReplyAction = "http://tempuri.org/IService1/GetDataResponse")]
        System.Threading.Tasks.Task<BookStoreBase.Resources.Book[]> GetDataAsync();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/AddBook", ReplyAction = "http://tempuri.org/IService1/AddBookResponse")]
        long AddBook(int val1, string str1, string str2, string str3, string str4, bool bool1);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/AddBook", ReplyAction = "http://tempuri.org/IService1/AddBookResponse")]
        System.Threading.Tasks.Task<long> AddBookAsync(int val1, string str1, string str2, string str3, string str4, bool bool1);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/DeleteBook", ReplyAction = "http://tempuri.org/IService1/DeleteBookResponse")]
        bool DeleteBook(long IDval);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/DeleteBook", ReplyAction = "http://tempuri.org/IService1/DeleteBookResponse")]
        System.Threading.Tasks.Task<bool> DeleteBookAsync(long IDval);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/EditBook", ReplyAction = "http://tempuri.org/IService1/EditBookResponse")]
        bool EditBook([System.ServiceModel.MessageParameterAttribute(Name = "editbook")] BookStoreBase.Resources.Book editbook1);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/EditBook", ReplyAction = "http://tempuri.org/IService1/EditBookResponse")]
        System.Threading.Tasks.Task<bool> EditBookAsync(BookStoreBase.Resources.Book editbook);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/ConnectDist", ReplyAction = "http://tempuri.org/IService1/ConnectDistResponse")]
        bool ConnectDist();

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IService1/ConnectDist", ReplyAction = "http://tempuri.org/IService1/ConnectDistResponse")]
        System.Threading.Tasks.Task<bool> ConnectDistAsync();
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    public interface IService1Channel : WpfApp1.Resources.IService, System.ServiceModel.IClientChannel
    {
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    public partial class Service1Client : System.ServiceModel.ClientBase<WpfApp1.Resources.IService>, WpfApp1.Resources.IService
    {

        public Service1Client()
        {
        }

        public Service1Client(string endpointConfigurationName) :
                base(endpointConfigurationName)
        {
        }

        public Service1Client(string endpointConfigurationName, string remoteAddress) :
                base(endpointConfigurationName, remoteAddress)
        {
        }

        public Service1Client(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress) :
                base(endpointConfigurationName, remoteAddress)
        {
        }

        public Service1Client(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) :
                base(binding, remoteAddress)
        {
        }

        public void InitData()
        {
            base.Channel.InitData();
        }

        public System.Threading.Tasks.Task InitDataAsync()
        {
            return base.Channel.InitDataAsync();
        }

        public BookStoreBase.Resources.Book[] GetData()
        {
            return base.Channel.GetData();
        }

        public System.Threading.Tasks.Task<BookStoreBase.Resources.Book[]> GetDataAsync()
        {
            return base.Channel.GetDataAsync();
        }

        public long AddBook(int val1, string str1, string str2, string str3, string str4, bool bool1)
        {
            return base.Channel.AddBook(val1, str1, str2, str3, str4, bool1);
        }

        public System.Threading.Tasks.Task<long> AddBookAsync(int val1, string str1, string str2, string str3, string str4, bool bool1)
        {
            return base.Channel.AddBookAsync(val1, str1, str2, str3, str4, bool1);
        }

        public bool DeleteBook(long IDval)
        {
            return base.Channel.DeleteBook(IDval);
        }

        public System.Threading.Tasks.Task<bool> DeleteBookAsync(long IDval)
        {
            return base.Channel.DeleteBookAsync(IDval);
        }

        public bool EditBook(BookStoreBase.Resources.Book editbook1)
        {
            return base.Channel.EditBook(editbook1);
        }

        public System.Threading.Tasks.Task<bool> EditBookAsync(BookStoreBase.Resources.Book editbook)
        {
            return base.Channel.EditBookAsync(editbook);
        }

        public bool ConnectDist()
        {
            return base.Channel.ConnectDist();
        }

        public System.Threading.Tasks.Task<bool> ConnectDistAsync()
        {
            return base.Channel.ConnectDistAsync();
        }
    }
}
