﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ServiceModel;
using WpfApp1.ServiceDist;
using System.Text.Json;

using BookStoreBase.Resources;

namespace WpfApp1.Resources
{
    public enum AccessFunc
    {
    }

    public class BookAccess
    {

        //service to make calls to
        private IService wcfClient1;
        public BookAccess()
        {
            
        }

        //get port number from service and setup wcfclient
        public void SetportNum()
        {
            //connect to service and get new port number
            ServiceDistClient distclient = new ServiceDistClient();
            string portnum = distclient.RequestPort();
            distclient.Close();
            //--Done--

            BasicHttpBinding myBinding = new BasicHttpBinding();
            EndpointAddress myEndpoint = new EndpointAddress("http://localhost:" + portnum + "/Service1.svc"); //63484 //53956

            ChannelFactory<IService> myChannelFactory = new ChannelFactory<IService>(myBinding, myEndpoint);

            // Create a channel.
            wcfClient1 = myChannelFactory.CreateChannel();
        }

        //deserialize the book data
        public List<Book> deserialize(string tempbooks)
        {
            return JsonSerializer.Deserialize<List<Book>>(tempbooks);
        }

        public List<Book> getbooks()
        {
            try
            {
                SetportNum();
                //string tempbooks = wcfClient1.GetData();
                //return deserialize(tempbooks);
                return wcfClient1.GetData().ToList();
            }
            catch
            {
                return null;
            }
        }

        public async Task<bool> deleteBook(Int64 ID)
        {
            try
            {
                SetportNum();
                bool temp = wcfClient1.DeleteBook(ID);
                return temp;
            }
            catch { }
            return false;
        }

        public async Task<Int64> addbook()
        {
            Int64 newid = -1;
            try
            {
                SetportNum();
                Int64 temp = wcfClient1.AddBook(-1, "", "", "", "", true);
                newid = temp;
            }
            catch
            {
                return newid;
            }
            return newid;
        }

        public async Task<bool> editBook(Book editbook)
        {
            try
            {
                SetportNum();
                bool temp = wcfClient1.EditBook(editbook);
                return temp;
            }
            catch { }
            return false;
        }
    }
}
